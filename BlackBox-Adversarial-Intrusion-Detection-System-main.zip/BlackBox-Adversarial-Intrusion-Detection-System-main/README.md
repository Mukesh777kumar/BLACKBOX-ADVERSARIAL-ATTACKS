# 🚨 BlackBox_IDS

### Adversarial Intrusion Detection System using Genetic Algorithms & Machine Learning

---

## 📌 Overview

**BlackBox_IDS** is an advanced Intrusion Detection System (IDS) that not only detects malicious network traffic but also evaluates the **robustness of ML models against adversarial attacks**.

A sophisticated Black-Box Intrusion Detection System (IDS) that not only detects malicious traffic but also generates adversarial attacks using Genetic Algorithms (GA) to evaluate and stress-test model robustness.

This project combines:

* 🧠 Machine Learning-based IDS (FNN, Random Forest, LightGBM)
* 🧬 Genetic Algorithm-based adversarial attack generation
* 📊 Evaluation of model performance under attack vs normal conditions

👉 The goal is to simulate **real-world evasion attacks** and test how well IDS models perform in adversarial environments.

---

## 🎯 Key Objectives

* Detect malicious (DDoS) vs benign traffic
* Generate adversarial network samples using Genetic Algorithms
* Evaluate model robustness under adversarial conditions
* Compare performance across multiple ML models

---

##🧠 Core Idea

Traditional IDS models perform well on clean data but often fail under adversarial manipulation.

This project:

Trains IDS models on network traffic
Uses a Genetic Algorithm (black-box attack) to craft malicious inputs
Tests how well models resist these attacks

👉 This simulates real-world evasion attacks on IDS systems

---

## 🧠 Models Implemented

| Model                            | Description                    |
| -------------------------------- | ------------------------------ |
| FNN (Feedforward Neural Network) | Deep learning-based classifier |
| Random Forest                    | Ensemble tree-based model      |
| LightGBM                         | Gradient boosting model        |
| Ensemble (Oracle)                | Combined predictions           |

---


🏗️ Project Architecture

                ┌────────────────────┐
                │   Dataset (DDoS)   │
                └────────┬───────────┘
                         │
                         ▼
                ┌────────────────────┐
                │   Model Training   │
                │ (FNN / RF / LGBM)  │
                └────────┬───────────┘
                         │
                         ▼
                ┌────────────────────┐
                │  Trained Models    │
                └────────┬───────────┘
                         │
                         ▼
                ┌────────────────────────────┐
                │ Genetic Algorithm Engine   │
                │ (Adversarial Generator)    │
                └────────┬───────────────────┘
                         │
                         ▼
                ┌────────────────────┐
                │   Evaluation       │
                │ Clean vs Attack    │
                └────────────────────┘


---

## ⚔️ Adversarial Attack Engine

The project includes a **custom Genetic Algorithm (GA)** to craft adversarial samples:

### 📂 `attack/`

* `ga_engine.py` → Core GA logic
* `genome.py` → Represents feature mutations
* `fitness.py` → Evaluates attack success
* `constraints.py` → Maintains realistic feature bounds

### 🔍 What it does:

* Takes malicious samples
* Applies controlled mutations
* Ensures features remain valid (using constraints)
* Optimizes to **bypass IDS detection**

---

## 📊 Dataset

### 📂 `dataset/`

* `ddos_attack_features.csv` → Malicious traffic
* `ddos_benign_features.csv` → Normal traffic
* `malicious_seeds.csv` → Initial attack samples
* `feature_bounds.json` → Constraints for adversarial generation

---

## 🏗️ Project Structure

```bash
BlackBox_IDS/
│
├── attack/                      # Genetic Algorithm attack engine
│   ├── ga_engine.py            # Core GA logic
│   ├── genome.py               # Individual representation
│   ├── fitness.py              # Fitness evaluation
│   ├── constraints.py          # Feature constraints
│
├── dataset/
│   ├── ddos_attack_features.csv
│   ├── ddos_benign_features.csv
│   ├── malicious_seeds.csv
│   ├── feature_bounds.json
│
├── training/
│   ├── train_ids.py            # Generic training
│   ├── train_fnn_ids.py        # Neural network training
│   ├── train_lgbm_ids.py       # LightGBM training
│
├── ids/                        # Saved models + inference
│   ├── fnn_model.pth
│   ├── rf_model.pkl
│   ├── lgbm_model.pkl
│   ├── oracle_*.py             # Model wrappers
│
├── evaluation/
│   ├── run_evaluation.py
│   ├── run_model_comparison.py
│   ├── plot_model_metrics.py
│   ├── plot_adversarial_metrics.py
│
├── results/
│   ├── clean_metrics.csv
│   ├── attack_metrics.csv
│
└── README.md
```

---

## ⚙️ Installation

```bash
git clone https://github.com/Harshit765G4/BlackBox_IDS.git
cd BlackBox_IDS
pip install -r requirements.txt
```

---

## ▶️ How to Run

### 1️⃣ Train Models

```bash
python training/train_fnn_ids.py
python training/train_ids.py
python training/train_lgbm_ids.py
```

---

### 2️⃣ Run Evaluation (Clean vs Attack)

```bash
python evaluation/run_evaluation.py
```

---

### 3️⃣ Compare Models

```bash
python evaluation/run_model_comparison.py
```

---

### 4️⃣ Generate Plots

```bash
python evaluation/plot_model_metrics.py
python evaluation/plot_adversarial_metrics.py
```

---

## 🔄 Workflow

```text
1. Load Dataset
2. Train IDS Models (FNN, RF, LGBM)
3. Generate Adversarial Samples (GA Engine)
4. Evaluate Models:
      - On clean data
      - On adversarial data
5. Compare performance
6. Visualize results
```

---

## 📈 Results

Results are stored in:

📂 `results/`

* `clean_metrics.csv` → Performance on normal data
* `attack_metrics.csv` → Performance under adversarial attack

### Metrics include:

* Accuracy
* Precision
* Recall
* F1-score

---

## ⚠️ Key Insights

* Models perform well on clean data but degrade under adversarial attacks
* Genetic Algorithm successfully creates realistic evasion samples
* Ensemble models improve robustness compared to single models

---

## 🚧 Limitations

* Uses static dataset (not real-time traffic)
* Black-box attack assumption (no gradient access)
* Limited feature engineering
* GA can be computationally expensive

---

## 🚀 Future Improvements

* 🔍 Add Explainable AI (XAI)
* ⚡ Real-time IDS deployment
* 🧠 Deep adversarial training
* 🌐 API-based inference system
* 📡 Integration with live network traffic

---

## 🤝 Contributing

Contributions are welcome!

1. Fork the repo
2. Create a new branch
3. Commit changes
4. Open a pull request

---

## 📜 License

MIT License

---

## 👤 Author

**Harshit Garg**
🔗 GitHub: https://github.com/Harshit765G4

---

If you found this project useful, consider giving it a ⭐
